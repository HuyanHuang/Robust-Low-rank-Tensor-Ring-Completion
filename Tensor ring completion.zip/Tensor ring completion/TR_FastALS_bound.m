function ERR=TR_FastALS_bound(model)
%% initialize parameters
maxiter=200;
val=model.val;
idx=model.idx;
siz=model.siz;
TRr=model.TRr;
gdt=model.gdt;
D=length(siz);
ERR=nan(maxiter,1);
%% preparation
P=zeros(siz);
P(idx)=1;
T=P.*reshape(1:prod(siz),siz);
C=cell(1,D);
ind=cell(1,D);
for d=1:D
    Wd=reshape(permute(P,[d d+1:D 1:d-1]),siz(d),[]);
    Td=reshape(permute(T,[d d+1:D 1:d-1]),siz(d),[]);
    for id=1:siz(d)
        ind{d}{id}=find(Wd(id,:));
        [~,~,v]=find(Td(id,:));
        [~,loc]=ismember(v,idx);
        C{d}{id}=val(loc)';
    end
end
%% tensor ring approximation
% x0=initialization_M(siz,idx,val);
x0=nan(siz);
x0(idx)=val;
x0=reshape(fillmissing(x0(:),'pchip'),siz);
g=TRcore_svd(siz,TRr,x0);
%% tensor ring completion
% main loop
for i=1:maxiter
    % original-BCD(block coordinate descent)
    % solve each sub-problem
    for d=1:D
        [A,B]=tensor_ring(g,d,siz);
        % slove each sub-sub-problem (update row by row)
        for id=1:siz(d)
            Bhat=B(:,ind{d}{id});
            Hess=Bhat*Bhat';
            A(id,:)=C{d}{id}*Bhat'/Hess;
        end
        g=ctensor_ring(g,d,A);
    end
    % calculate newly recovered tensor
    [~,~,x]=tensor_ring(g,1,siz);
    % compute relative error with respect to cost function
%     RC(i)=norm(x(:)-x0(:),2)/norm(x0(:),2);
    ERR(i)=norm((x(:)-gdt(:)).*(1-P(:)),2)^2-norm((x(:)-gdt(:)).*P(:),2)^2;
%     if mod(i,10)==0
%         fprintf('Iteration=%d\tRE=%f\n',i,RE(i));
%     end
%     if RC(i)<epsilon_x
%         flag=true;
%         break
%     end
%     x0=x;
end
end