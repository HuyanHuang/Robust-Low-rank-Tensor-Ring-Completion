function [x,SSE,RMSE,run_time,g]=TR_FastALS(model,flag)
%% initialize parameters
maxiter=100;
epsilon_x=1e-8;
val=model.val;
idx=model.idx;
siz=model.siz;
TRr=model.TRr;
gdt=model.gdt;
lambda=model.pnt;
method=model.int;
D=length(siz);
%% preparation
P=zeros(siz);
P(idx)=1;
T=P.*reshape(1:prod(siz),siz);
C=cell(1,D);
ind=cell(1,D);
for d=1:D
    Wd=reshape(permute(P,[d d+1:D 1:d-1]),siz(d),[]);
    Td=reshape(permute(T,[d d+1:D 1:d-1]),siz(d),[]);
    for id=1:siz(d)
        ind{d}{id}=find(Wd(id,:));
        [~,~,v]=find(Td(id,:));
        [~,loc]=ismember(v,idx);
        C{d}{id}=val(loc)';
    end
end
SSE=nan(maxiter,1);
RMSE=nan(maxiter,1);
%% tensor ring approximation
% x0=initialization_M(siz,idx,val);
x0=nan(siz);
x0(idx)=val;
x0=reshape(fillmissing(x0(:),'pchip'),siz);
[~,g]=TR_init(siz,TRr,method,x0);
%% tensor ring completion
t=cputime;
% main loop
for i=1:maxiter
    % original-BCD(block coordinate descent)
    % solve each sub-problem
    for d=1:D
        [A,B]=tensor_ring(g,d,siz);
        % slove each sub-sub-problem (update row by row)
        for id=1:siz(d)
            Bhat=B(:,ind{d}{id});
            Hess=Bhat*Bhat';
            A(id,:)=C{d}{id}*Bhat'/(Hess+lambda*eye(size(Hess)));
%             A(id,:)=lsqminnorm(Bhat',C{d}{id}');
        end
        g=ctensor_ring(g,d,A);
    end
    % calculate newly recovered tensor
    [~,~,x]=tensor_ring(g,1,siz);
    % compute relative change
    RC=re(x-x0,x0);
    SSE(i)=sse(x,idx,val);
    RMSE(i)=rmse(x,gdt);
    if flag && mod(i,10)==0
        fprintf('Iteration=%d\tSSE=%g\tRMSE=%g\n',i,SSE(i),RMSE(i));
    end
%     if RC<epsilon_x
%         break
%     end
    x0=x;
    if mod(i,10)==0
        lambda=lambda/10;
        if lambda<1e-6
            lambda=0;
        end
    end
end
run_time=cputime-t;
fprintf('Elapesd time=%gs\n',run_time);
end