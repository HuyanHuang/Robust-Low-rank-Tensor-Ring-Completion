function [x,RC,RE,run_time,g]=TR_ALS(tnsr,P,TRr,flag)
%% initialize parameters
maxiter=100;
epsilon_x=1e-8;
D=ndims(tnsr);
siz=size(tnsr);
RC=nan(maxiter,1);
RE=nan(maxiter,1);
F0=norm(tnsr(:),2);
%% tensor ring approximation
% x0=initialization_M(J,find(P),tnsr(P==1));
idx=P==1;
x0=nan(siz);
x0(idx)=tnsr(idx);
x0=reshape(fillmissing(x0(:),'pchip'),siz);
g=TRcore_svd(siz,TRr,P.*tnsr);
%% tensor ring completion
t=cputime;
% main loop
for i=1:maxiter
    % original-BCD(block coordinate descent)
    % solve each sub-problem
    for n=1:D
        [A,B]=tensor_ring(g,n,siz);
        C_temp=permute(P.*tnsr,[n n+1:D 1:n-1]);
        C=reshape(C_temp,siz(n),[]);
        W_temp=permute(P,[n n+1:D 1:n-1]);
        W=reshape(W_temp,siz(n),[]);
        % slove each sub-sub-problem (update row by row)
        for j=1:size(A,1)
            Bhat=B(:,W(j,:)==1);
            Hess_row=Bhat*Bhat';
            A(j,:)=C(j,:)*B'/Hess_row;
            
%             A(j,:)=lsqminnorm(Hess_row,B*C(j,:)');
        end
        g=ctensor_ring(g,n,A);
    end
    % calculate newly recovered tensor
    [~,~,x]=tensor_ring(g,1,siz);
    % compute relative error with respect to cost function
    RC(i)=norm(x(:)-x0(:),2)/norm(x0(:),2);
    RE(i)=norm(x(:)-tnsr(:),2)/F0;
    if flag && mod(i,10)==0
        fprintf('Iteration=%d\tRC=%f\tRE=%f\n',i,RC(i),RE(i));
    end
%     if RC(i)<epsilon_x
%         break
%     end
    x0=x;
end
run_time=cputime-t;
fprintf('running time=%fs\n',run_time);
end