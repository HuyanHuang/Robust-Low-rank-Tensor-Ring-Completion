clc
clear
g=cell(3,1);
I=[10 15 20];
tnsr0=zeros(I);
R=[3 4 5];
for i=1:2
    g{i}=rand(R(i),I(i),R(i+1));
end
g{3}=rand(R(3),I(3),R(1));
tic
for i=1:I(1)
    for j=1:I(2)
        for k=1:I(3)
            tnsr0(i,j,k)=trace(squeeze(g{1}(:,i,:))*squeeze(g{2}(:,j,:))*squeeze(g{3}(:,k,:)));
        end
    end
end
toc
tic
[A,~,tnsr1]=tensor_ring(g,2,I);
toc
norm(tnsr1(:)-tnsr0(:),2)
g1=g;
g1=ctensor_ring(g1,2,A);
isequal(g1{2},g{2})