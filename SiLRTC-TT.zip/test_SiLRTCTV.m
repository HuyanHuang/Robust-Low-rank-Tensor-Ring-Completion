% test 8 images using SiLRTC_TT+TV method
%SiLRTC_TT+KA+TV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\peppers.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save peppers.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\barbara.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save barbara.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\airplane.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save airplane.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\baboon.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save baboon.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\house.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save house.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\facade.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save facade.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\sailboat.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save sailboat.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\lena.bmp'));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X] = SmoothlowTTrank_TV12( y, known, rho,y,w);
 time_TTTV(ObsRatio)=toc;
SiLRTCTV(:,:,:,ObsRatio)=X;
psnr_TTTV(ObsRatio)=psnr(X,T);
RSE_TTTV(ObsRatio)=RSE(T(:),X(:));
SSIM_TTTV(ObsRatio)=ssim(T,X);
end
save lena.mat time_TTTV SiLRTCTV psnr_TTTV RSE_TTTV SSIM_TTTV