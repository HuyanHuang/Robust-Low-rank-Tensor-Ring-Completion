
for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\peppers.mat');
  psnr_STCas_peppers(100-i)=psnr_STCas(i);
  SSIM_STCas_peppers(100-i)=SSIM_STCas(i);
 RSE_STCas_peppers(100-i)=RSE_STCas(i);
  timeas_peppers(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\peppers.mat');
 psnr_TT_peppers(100-i)=psnr_TT(i);
 SSIM_TT_peppers(100-i)=SSIM_TT(i);
RSE_TT_peppers(100-i)=RSE_TT(i);
time_TT_peppers(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\peppers.mat');
 psnr_TTTV_peppers(100-i)=psnr_TTTV(i);
  SSIM_TTTV_peppers(100-i)=SSIM_TTTV(i);
  RSE_TTTV_peppers(100-i)=RSE_TTTV(i);
    time_TTTV_peppers(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\peppers.mat');
  psnr_TTNTV_peppers(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_peppers(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_peppers(100-i)=RSE_TTNTV(i); 
    time_TTNTV_peppers(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\barbara.mat');
  psnr_STCas_barbara(100-i)=psnr_STCas(i);
  SSIM_STCas_barbara(100-i)=SSIM_STCas(i);
 RSE_STCas_barbara(100-i)=RSE_STCas(i);
   timeas_barbara(100-i)=timeas(i);

 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\barbara.mat');
 psnr_TT_barbara(100-i)=psnr_TT(i);
 SSIM_TT_barbara(100-i)=SSIM_TT(i);
RSE_TT_barbara(100-i)=RSE_TT(i);
time_TT_barbara(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\barbara.mat');
 psnr_TTTV_barbara(100-i)=psnr_TTTV(i);
  SSIM_TTTV_barbara(100-i)=SSIM_TTTV(i);
  RSE_TTTV_barbara(100-i)=RSE_TTTV(i);
      time_TTTV_barbara(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\barbara.mat');
  psnr_TTNTV_barbara(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_barbara(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_barbara(100-i)=RSE_TTNTV(i); 
      time_TTNTV_barbara(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\airplane.mat');
  psnr_STCas_airplane(100-i)=psnr_STCas(i);
  SSIM_STCas_airplane(100-i)=SSIM_STCas(i);
 RSE_STCas_airplane(100-i)=RSE_STCas(i);
    timeas_airplane(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\airplane.mat');
 psnr_TT_airplane(100-i)=psnr_TT(i);
 SSIM_TT_airplane(100-i)=SSIM_TT(i);
RSE_TT_airplane(100-i)=RSE_TT(i);
time_TT_airplane(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\airplane.mat');
 psnr_TTTV_airplane(100-i)=psnr_TTTV(i);
  SSIM_TTTV_airplane(100-i)=SSIM_TTTV(i);
  RSE_TTTV_airplane(100-i)=RSE_TTTV(i);
  time_TTTV_airplane(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\airplane.mat');
  psnr_TTNTV_airplane(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_airplane(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_airplane(100-i)=RSE_TTNTV(i);
 time_TTNTV_airplane(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\baboon.mat');
  psnr_STCas_baboon(100-i)=psnr_STCas(i);
  SSIM_STCas_baboon(100-i)=SSIM_STCas(i);
 RSE_STCas_baboon(100-i)=RSE_STCas(i);
     timeas_baboon(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\baboon.mat');
 psnr_TT_baboon(100-i)=psnr_TT(i);
 SSIM_TT_baboon(100-i)=SSIM_TT(i);
RSE_TT_baboon(100-i)=RSE_TT(i);
time_TT_baboon(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\baboon.mat');
 psnr_TTTV_baboon(100-i)=psnr_TTTV(i);
  SSIM_TTTV_baboon(100-i)=SSIM_TTTV(i);
  RSE_TTTV_baboon(100-i)=RSE_TTTV(i);
    time_TTTV_baboon(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\baboon.mat');
  psnr_TTNTV_baboon(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_baboon(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_baboon(100-i)=RSE_TTNTV(i);
   time_TTNTV_baboon(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\house.mat');
  psnr_STCas_house(100-i)=psnr_STCas(i);
  SSIM_STCas_house(100-i)=SSIM_STCas(i);
 RSE_STCas_house(100-i)=RSE_STCas(i);
      timeas_house(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\house.mat');
 psnr_TT_house(100-i)=psnr_TT(i);
 SSIM_TT_house(100-i)=SSIM_TT(i);
RSE_TT_house(100-i)=RSE_TT(i);
time_TT_house(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\house.mat');
 psnr_TTTV_house(100-i)=psnr_TTTV(i);
  SSIM_TTTV_house(100-i)=SSIM_TTTV(i);
  RSE_TTTV_house(100-i)=RSE_TTTV(i);
      time_TTTV_house(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\house.mat');
  psnr_TTNTV_house(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_house(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_house(100-i)=RSE_TTNTV(i); 
     time_TTNTV_house(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\facade.mat');
  psnr_STCas_facade(100-i)=psnr_STCas(i);
  SSIM_STCas_facade(100-i)=SSIM_STCas(i);
 RSE_STCas_facade(100-i)=RSE_STCas(i);
       timeas_facade(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\facade.mat');
 psnr_TT_facade(100-i)=psnr_TT(i);
 SSIM_TT_facade(100-i)=SSIM_TT(i);
RSE_TT_facade(100-i)=RSE_TT(i);
time_TT_facade(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\facade.mat');
 psnr_TTTV_facade(100-i)=psnr_TTTV(i);
  SSIM_TTTV_facade(100-i)=SSIM_TTTV(i);
  RSE_TTTV_facade(100-i)=RSE_TTTV(i);
  time_TTTV_facade(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\facade.mat');
  psnr_TTNTV_facade(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_facade(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_facade(100-i)=RSE_TTNTV(i); 
     time_TTNTV_facade(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\sailboat.mat');
  psnr_STCas_sailboat(100-i)=psnr_STCas(i);
  SSIM_STCas_sailboat(100-i)=SSIM_STCas(i);
 RSE_STCas_sailboat(100-i)=RSE_STCas(i);
        timeas_sailboat(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\sailboat.mat');
 psnr_TT_sailboat(100-i)=psnr_TT(i);
 SSIM_TT_sailboat(100-i)=SSIM_TT(i);
RSE_TT_sailboat(100-i)=RSE_TT(i);
time_TT_sailboat(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\sailboat.mat');
 psnr_TTTV_sailboat(100-i)=psnr_TTTV(i);
  SSIM_TTTV_sailboat(100-i)=SSIM_TTTV(i);
  RSE_TTTV_sailboat(100-i)=RSE_TTTV(i);
  time_TTTV_sailboat(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\sailboat.mat');
  psnr_TTNTV_sailboat(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_sailboat(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_sailboat(100-i)=RSE_TTNTV(i); 
       time_TTNTV_sailboat(100-i)=time_TTNTV(i);
end

for i=10:10:60
  load('F:\documents\����\����20150525\demo_SiLRTC\STTC\lena.mat');
  psnr_STCas_lena(100-i)=psnr_STCas(i);
  SSIM_STCas_lena(100-i)=SSIM_STCas(i);
 RSE_STCas_lena(100-i)=RSE_STCas(i);
         timeas_lena(100-i)=timeas(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA\lena.mat');
 psnr_TT_lena(100-i)=psnr_TT(i);
 SSIM_TT_lena(100-i)=SSIM_TT(i);
RSE_TT_lena(100-i)=RSE_TT(i);
time_TT_lena(100-i)=time_TT(i);
 load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+KA+TV\lena.mat');
 psnr_TTTV_lena(100-i)=psnr_TTTV(i);
  SSIM_TTTV_lena(100-i)=SSIM_TTTV(i);
  RSE_TTTV_lena(100-i)=RSE_TTTV(i);
    time_TTTV_lena(100-i)=time_TTTV(i);
  load('F:\documents\����\����20150525\demo_SiLRTC\SiLRTCTT+NKA+TV\lena.mat');
  psnr_TTNTV_lena(100-i)=psnr_TTNTV(i);
  SSIM_TTNTV_lena(100-i)=SSIM_TTNTV(i);
  RSE_TTNTV_lena(100-i)=RSE_TTNTV(i);
         time_TTNTV_lena(100-i)=time_TTNTV(i);
end



  i=40:10:90;
 figure(1), subplot(2,4,1) ,
plot(i,psnr_STCas_peppers(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_peppers(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_peppers(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_peppers(i),'k-x','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('��_1');
legend('STTC','SiLRTCTT+KA','SiLRTCTT+TV','SiLRTCTT+KA+TV');


subplot(2,4,2) ,
plot(i,psnr_STCas_barbara(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_barbara(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_barbara(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_barbara(i),'k-x','linewidth',1.5);
title( 'barbara' );
xlabel('missing ratio');
ylabel('PSNR');

subplot(2,4,3) ,
plot(i,psnr_STCas_airplane(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_airplane(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_airplane(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_airplane(i),'k-x','linewidth',1.5);
title( 'airplane' );
xlabel('missing ratio');
ylabel('PSNR');
% legend( 'SPC-QV','SPC-TV','STC-AS','STC-IS','RoTu','LRTC-PDS','HaLRTC');

 subplot(2,4,4) ,
plot(i,psnr_STCas_baboon(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_baboon(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_baboon(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_baboon(i),'k-x','linewidth',1.5);
title( 'baboon' );
xlabel('missing ratio');
ylabel('PSNR');

 subplot(2,4,5) ,
plot(i,psnr_STCas_house(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_house(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_house(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_house(i),'k-x','linewidth',1.5);
title( 'house' );
xlabel('missing ratio');
ylabel('PSNR');

 subplot(2,4,6) ,
plot(i,psnr_STCas_facade(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_facade(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_facade(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_facade(i),'k-x','linewidth',1.5);
title( 'facade' );
xlabel('missing ratio');
ylabel('PSNR');

 subplot(2,4,7) ,
plot(i,psnr_STCas_sailboat(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_sailboat(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_sailboat(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_sailboat(i),'k-x','linewidth',1.5);
title( 'sailboat' );
xlabel('missing ratio');
ylabel('PSNR');
 subplot(2,4,8) ,
plot(i,psnr_STCas_lena(i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT_lena(i),'b-*','linewidth',1.5);
hold on;
plot(i,psnr_TTNTV_lena(i),'c-v','linewidth',1.5);
hold on;
plot(i,psnr_TTTV_lena(i),'k-x','linewidth',1.5);
title( 'lena' );
xlabel('missing ratio');
ylabel('PSNR');

figure(2), subplot(2,4,1) ,
plot(i,SSIM_STCas_peppers(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_peppers(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_peppers(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_peppers(i),'k-x','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('SSIM');
legend('STTC','SiLRTCTT+KA','SiLRTCTT+TV','SiLRTCTT+KA+TV');


subplot(2,4,2) ,
plot(i,SSIM_STCas_barbara(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_barbara(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_barbara(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_barbara(i),'k-x','linewidth',1.5);
title( 'barbara' );
xlabel('missing ratio');
ylabel('SSIM');

subplot(2,4,3) ,
plot(i,SSIM_STCas_airplane(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_airplane(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_airplane(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_airplane(i),'k-x','linewidth',1.5);
title( 'airplane' );
xlabel('missing ratio');
ylabel('SSIM');
% legend( 'SPC-QV','SPC-TV','STC-AS','STC-IS','RoTu','LRTC-PDS','HaLRTC');

 subplot(2,4,4) ,
plot(i,SSIM_STCas_baboon(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_baboon(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_baboon(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_baboon(i),'k-x','linewidth',1.5);
title( 'baboon' );
xlabel('missing ratio');
ylabel('SSIM');

 subplot(2,4,5) ,
plot(i,SSIM_STCas_house(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_house(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_house(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_house(i),'k-x','linewidth',1.5);
title( 'house' );
xlabel('missing ratio');
ylabel('SSIM');

 subplot(2,4,6) ,
plot(i,SSIM_STCas_facade(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_facade(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_facade(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_facade(i),'k-x','linewidth',1.5);
title( 'facade' );
xlabel('missing ratio');
ylabel('SSIM');

 subplot(2,4,7) ,
plot(i,SSIM_STCas_sailboat(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_sailboat(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_sailboat(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_sailboat(i),'k-x','linewidth',1.5);
title( 'sailboat' );
xlabel('missing ratio');
ylabel('SSIM');
 subplot(2,4,8) ,
plot(i,SSIM_STCas_lena(i),'r-p','linewidth',1.5);
hold on;
plot(i,SSIM_TT_lena(i),'b-*','linewidth',1.5);
hold on;
plot(i,SSIM_TTNTV_lena(i),'c-v','linewidth',1.5);
hold on;
plot(i,SSIM_TTTV_lena(i),'k-x','linewidth',1.5);
title( 'lena' );
xlabel('missing ratio');
ylabel('SSIM');

figure(3), subplot(2,4,1) ,
plot(i,RSE_STCas_peppers(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_peppers(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_peppers(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_peppers(i),'k-x','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('RSE');
legend('STTC','SiLRTCTT+KA','SiLRTCTT+TV','SiLRTCTT+KA+TV');


subplot(2,4,2) ,
plot(i,RSE_STCas_barbara(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_barbara(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_barbara(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_barbara(i),'k-x','linewidth',1.5);
title( 'barbara' );
xlabel('missing ratio');
ylabel('RSE');

subplot(2,4,3) ,
plot(i,RSE_STCas_airplane(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_airplane(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_airplane(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_airplane(i),'k-x','linewidth',1.5);
title( 'airplane' );
xlabel('missing ratio');
ylabel('RSE');
% legend( 'SPC-QV','SPC-TV','STC-AS','STC-IS','RoTu','LRTC-PDS','HaLRTC');

 subplot(2,4,4) ,
plot(i,RSE_STCas_baboon(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_baboon(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_baboon(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_baboon(i),'k-x','linewidth',1.5);
title( 'baboon' );
xlabel('missing ratio');
ylabel('RSE');

 subplot(2,4,5) ,
plot(i,RSE_STCas_house(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_house(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_house(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_house(i),'k-x','linewidth',1.5);
title( 'house' );
xlabel('missing ratio');
ylabel('RSE');

 subplot(2,4,6) ,
plot(i,RSE_STCas_facade(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_facade(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_facade(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_facade(i),'k-x','linewidth',1.5);
title( 'facade' );
xlabel('missing ratio');
ylabel('RSE');

 subplot(2,4,7) ,
plot(i,RSE_STCas_sailboat(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_sailboat(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_sailboat(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_sailboat(i),'k-x','linewidth',1.5);
title( 'sailboat' );
xlabel('missing ratio');
ylabel('RSE');
 subplot(2,4,8) ,
plot(i,RSE_STCas_lena(i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT_lena(i),'b-*','linewidth',1.5);
hold on;
plot(i,RSE_TTNTV_lena(i),'c-v','linewidth',1.5);
hold on;
plot(i,RSE_TTTV_lena(i),'k-x','linewidth',1.5);
title( 'lena' );
xlabel('missing ratio');
ylabel('RSE');

figure(4), subplot(2,4,1) ,
plot(i,timeas_peppers(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_peppers(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_peppers(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_peppers(i),'k-x','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');
legend('STTC','SiLRTCTT+KA','SiLRTCTT+TV','SiLRTCTT+KA+TV');


subplot(2,4,2) ,
plot(i,timeas_barbara(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_barbara(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_barbara(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_barbara(i),'k-x','linewidth',1.5);
title( 'barbara' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');

subplot(2,4,3) ,
plot(i,timeas_airplane(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_airplane(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_airplane(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_airplane(i),'k-x','linewidth',1.5);
title( 'airplane' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');
% legend( 'SPC-QV','SPC-TV','STC-AS','STC-IS','RoTu','LRTC-PDS','HaLRTC');

 subplot(2,4,4) ,
plot(i,timeas_baboon(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_baboon(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_baboon(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_baboon(i),'k-x','linewidth',1.5);
title( 'baboon' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');

 subplot(2,4,5) ,
plot(i,timeas_house(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_house(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_house(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_house(i),'k-x','linewidth',1.5);
title( 'house' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');

 subplot(2,4,6) ,
plot(i,timeas_facade(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_facade(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_facade(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_facade(i),'k-x','linewidth',1.5);
title( 'facade' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');

 subplot(2,4,7) ,
plot(i,timeas_sailboat(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_sailboat(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_sailboat(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_sailboat(i),'k-x','linewidth',1.5);
title( 'sailboat' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');
 subplot(2,4,8) ,
plot(i,timeas_lena(i),'r-p','linewidth',1.5);
hold on;
plot(i,time_TT_lena(i),'b-*','linewidth',1.5);
hold on;
plot(i,time_TTNTV_lena(i),'c-v','linewidth',1.5);
hold on;
plot(i,time_TTTV_lena(i),'k-x','linewidth',1.5);
title( 'lena' );
xlabel('missing ratio');
ylabel('CPU time (seconds)');


