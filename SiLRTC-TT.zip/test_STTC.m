% test 8 images using STTC method
%STTC-A
clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\peppers.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=2/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
SSIM_STCas(ObsRatio)=ssim(T,X_as);
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=5/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
SSIM_STCis(ObsRatio)=ssim(T,X_is);
end
save peppers.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis SSIM_STCas SSIM_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\barbara.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save barbara.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\airplane.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save airplane.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\baboon.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save baboon.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\house.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save house.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\facade.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save facade.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\sailboat.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save sailboat.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\lena.bmp'));
Nway =size(T);
for ObsRatio=10:10:60
% ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=2/1000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(ObsRatio)=toc;
STCis(:,:,:,ObsRatio)=X_is;
psnr_STCis(ObsRatio)=psnr(X_is,T);
RSE_STCis(ObsRatio)=RSE(T(:),X_is(:));
end
save lena.mat timeas STCas psnr_STCas RSE_STCas timeis STCis psnr_STCis RSE_STCis

