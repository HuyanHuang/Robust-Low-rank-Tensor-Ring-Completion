i=40:10:90
figure;
plot(i,psnr_STCas(100-i),'r-p','linewidth',1.5);
hold on;
plot(i,psnr_TT(100-i),'b-*','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('PSNR');
legend('TT','TT+TV');

figure;
plot(i,RSE_STCas(100-i),'r-p','linewidth',1.5);
hold on;
plot(i,RSE_TT(100-i),'b-*','linewidth',1.5);
title( 'peppers' );
xlabel('missing ratio');
ylabel('RSE');
legend('TT','TT+TV');

figure;
plot(i,timeas(100-i),'r-p','linewidth',1.5);
hold on;
plot(i,Timeas(100-i),'b-*','linewidth',1.5);
title( 'lena' );
xlabel('missing ratio');
ylabel('CPU time(seconds)');
legend('STTC','TT+TV');