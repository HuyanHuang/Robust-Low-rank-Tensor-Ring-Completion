%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Simple Low Rank Tensor Completion (SiLRTC) 
% Time: 03/11/2012
% Reference: "Tensor Completion for Estimating Missing Values 
% in Visual Data", PAMI, 2012.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X] = update_TTX(T, alpha, gamma)
%%%%%%%%%%%%%%%%%%%%%%%%%%
% min(X, M1, M2, M3,... Mn): (\gamma1||X_(1)-M1||^2 + \gamma2||X_(2)-T2||^2 + \gamma3||X_(3)-T3||^2 + ...)/2 + 
%               \alpha1||M1||_* + \alpha2||M2||_* + \alpha3||M3||_* + ....
%         s.t.  X_\Omega = T_\Omega
%%%%%%%%%%%%%%%%%%%%%%%%%%
Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
N = numel(Nway);
I1 = 2; J1 = 2;   
X= CastImageAsKet(T,Nway,I1,J1);
% errList = zeros(maxIter, 1);
% normT = norm(X(:));
%L = errList;
dim = size(X);
M = cell(ndims(X), 1);
gammasum = sum(gamma);
tau = alpha./ gamma;

%normT = norm(T(:));

    Xsum = 0;
    for i = 1:ndims(X)-1
        M{i} = Fold_Xn(Pro2TraceNorm(Unfold_Xn(X, dim, i), tau(i)), dim, i);
        Xsum = Xsum + gamma(i) * M{i};
    end
    X = Xsum / gammasum;
     R=256;C=256;I1=2;J1=2;
    X = CastKet2Image(X,R,C,I1,J1);