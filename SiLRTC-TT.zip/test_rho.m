clear; close all; clc;
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\airplane.bmp'));
Nway =size(T);
% for ObsRatio=10:10:60
ObsRatio=20;
Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
for i=10:10:200
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=i/100000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
timeas(i)=toc;
STCas(:,:,:,i)=X_as;
psnr_STCas(i)=psnr(X_as,T);
RSE_STCas(i)=RSE(T(:),X_as(:));
SSIM_STCas(i)=ssim(T,X_as);
%  rho=0.2%for isotropio TV 
 w=[2,2,0];
 rho=i/10000;
[X_is] = Smoothlowrank_TV1( y, known, rho,y,w);
timeis(i)=toc;
STCis(:,:,:,i)=X_is;
psnr_STCis(i)=psnr(X_is,T);
RSE_STCis(i)=RSE(T(:),X_is(:));
SSIM_STCis(i)=ssim(T,X_is);
end
i=10:10:200
plot(i,psnr_STCas(i),'r-o');
hold on;
plot(i,psnr_STCis(i),'b--');
legend('AS','IS');
