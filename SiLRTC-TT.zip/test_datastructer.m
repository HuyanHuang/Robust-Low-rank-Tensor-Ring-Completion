%test data structer
clear; close all; clc;
T = imread('F:\documents\����\Journal materials\datasets\color image\TestImages\peppers.bmp');
A=T(:,:,1);
% Initial parameters
Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
N = numel(Nway);
I1 = 2; J1 = 2;                 % KA parameters
% Ket Augmentation
T1 = CastImageAsKet(T,Nway,I1,J1);
vObj = VideoReader('traffic.avi');
nFrames = vObj.NumberOfFrames;

%��ȡ��ƵƬ��
myMovie = read(vObj,[1 nFrames-1]);
%% д��Ƶ
%��ʼ��
myVideo = VideoWriter('myfile.avi', 'Uncompressed AVI');
myVideo.FrameRate = 15;  
n=1
for i=2:2:256
    for j=2:2:256
        K(n,:)=T(i,j,:);
        n=n+1;
    end
end
