clc;
clear; 
fig='peppers';
imgfile = strcat('C:\Users\����\Desktop\demo_SiLRTC\Test_data/',fig,'.bmp');
T = im2double(imread(imgfile));
Nway =size(T);
for ObsRatio=10:10:60

Omega = randperm(prod(Nway));
Omega = Omega(1:round((ObsRatio/100)*prod(Nway)));
O = zeros(Nway);
O(Omega) = 1;
y=T.*O;
known=find(y);

tic;
% rho=0.2; %for anisotropio TV 
w=[4,4,0];
rho=5/10000;
[X_as] = SmoothlowTTrank_TV12( y, known, rho,y,w);
timeas(ObsRatio)=toc;
STCas(:,:,:,ObsRatio)=X_as;
psnr_STCas(ObsRatio)=psnr(X_as,T);
RSE_STCas(ObsRatio)=RSE(T(:),X_as(:));
end