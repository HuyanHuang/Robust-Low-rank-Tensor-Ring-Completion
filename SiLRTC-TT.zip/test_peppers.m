clear; close all; clc;

% Initial parameters
Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
N = numel(Nway);
I1 = 2; J1 = 2;                 % KA parameters

% % Image selection 
% fig='lena';
fig='peppers';
imgfile = strcat('C:\Users\����\Desktop\demo_SiLRTC\Test_data/',fig,'.bmp');
T = im2double(imread(imgfile));

% Ket Augmentation
T1 = CastImageAsKet(T,Nway,I1,J1);
for i=10:10:60
SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
mr = (1-SR)*100;                % Missing ratio (mr);
Y=zeros(Nway);
% Generate known data
P = round(SR*prod(Nway));
Known = randsample(prod(Nway),P);
Y(Known)=T1(Known);
maxIter=500;
alpha=[4,16,64,256,192,48,12,3];
gamma=0.01*alpha*256;
epsilon=1e-5;
tic;
 [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
     R=256;C=256;I1=2;J1=2;
 X = CastKet2Image(X,R,C,I1,J1);
 time_TT(i)=toc;
SiLRTCTC(:,:,:,i)=X;
psnr_TT(i)=psnr(X,T);
RSE_TT(i)=RSE(T(:),X(:));
end
