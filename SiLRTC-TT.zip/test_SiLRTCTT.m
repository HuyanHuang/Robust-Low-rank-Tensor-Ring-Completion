% test 8 images using SiLRTC_TT method
%SiLRTC_TT+KA

clear; close all; clc;
T = im2double(imread('peppers.bmp'));
% Initial parameters
Nway=size(T);
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
N = numel(Nway);
I1 = 2; J1 = 2;                 % KA parameters
% Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% T1=reshape(T,Nway);
%for i=10:10:60
SR =10/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
mr = (1-SR)*100;                % Missing ratio (mr);
Y=zeros(Nway);
% Generate known data
P = round(SR*prod(Nway));
Known = randsample(prod(Nway),P);
Y(Known)=T(Known);
maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
alpha=[256 3];
gamma=0.01*alpha*256;
epsilon=1e-5;
tic;
 [X] = SiLRTC_TT1(Y, Known, alpha, gamma, maxIter,epsilon);
 
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
% %  time_TT(i)=toc;
% SiLRTCTC{i}=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save peppers.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\barbara.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save barbara.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\airplane.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save airplane.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\baboon.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save baboon.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\house.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save house.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\facade.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save facade.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\sailboat.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save sailboat.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT
% 
% clear; close all; clc;
% T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\lena.bmp'));
% % Initial parameters
% Nway = [4 4 4 4 4 4 4 4 3];     % 9th-order dimensions for KA
% N = numel(Nway);
% I1 = 2; J1 = 2;                 % KA parameters
% % Ket Augmentation
% T1 = CastImageAsKet(T,Nway,I1,J1);
% for i=10:10:60
% SR =i/100;                    % Sample ratio (SR), e.g. 0.1 = 10% known samples
% mr = (1-SR)*100;                % Missing ratio (mr);
% Y=zeros(Nway);
% % Generate known data
% P = round(SR*prod(Nway));
% Known = randsample(prod(Nway),P);
% Y(Known)=T1(Known);
% maxIter=500;
% alpha=[4,16,64,256,192,48,12,3];
% gamma=0.005*alpha*256;
% epsilon=1e-5;
% tic;
%  [X] = SiLRTC_TT1(T1, Known, alpha, gamma, maxIter,epsilon);
%      R=256;C=256;I1=2;J1=2;
%  X = CastKet2Image(X,R,C,I1,J1);
%  time_TT(i)=toc;
% SiLRTCTC(:,:,:,i)=X;
% psnr_TT(i)=psnr(X,T);
% RSE_TT(i)=RSE(T(:),X(:));
% SSIM_TT(i)=ssim(T,X);
% end
% save lena.mat time_TT SiLRTCTC psnr_TT RSE_TT SSIM_TT

