function [X] = Fold_Xn(X, dim, i)
X = reshape(X,dim);