function [X] = Unfold_Xn( X, dim, i )
X = reshape(X, prod(dim(1:i)), []);