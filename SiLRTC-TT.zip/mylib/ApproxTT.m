function [X]=ApproxTT(T)
   %initional
   maxIter=500;
    [n1,n2,n3,n4]=size(T);
    alpha=[n1,n1*n2,n4];
    gamma=0.005*alpha;
    epsilon=1e-5;

    normT = norm(T(:));
    dim = size(T);
    M = cell(ndims(T), 1);
    gammasum = sum(gamma);
    tau = alpha./ gamma;
    X=T;
%normT = norm(T(:));
for k = 1:maxIter
    Xsum = 0;
    for i = 1:ndims(T)-1
        M{i} = Fold_Xn(Pro2TraceNorm(Unfold_Xn(X, dim, i), tau(i)), dim, i);
        Xsum = Xsum + gamma(i) * M{i};
    end
    Xlast = X;
    X = Xsum / gammasum;
    errList(k) = norm(X(:)-Xlast(:)) / normT;
    if (errList(k) < epsilon)
        errList = errList(1:k);
        break;
    end
    %L(k) = norm(X(:)-T(:)) / normT;
end
end
     