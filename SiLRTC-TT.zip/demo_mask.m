I=imread('printedtext.png');
            BW=imbinarize(I,'adaptive','ForegroundPolarity','dark','Sensitivity',0.4);
            P=imresize(BW,[256,256]);
            P=cat(3,P,P,P);
            P=double(P);
T = im2double(imread('F:\documents\����\Journal materials\datasets\color image\TestImages\house.bmp'));
Nway =size(T);

y=T.*P;
known=find(y);

tic;

w=[8,8,0];
rho=2/1000;
[X_as] = Smoothlowrank_TV12( y, known, rho,y,w);
psnr(X_as,T)
RSE(T(:),X_as(:))